// add sticky navigation bar

// activate the hamburger menu and mobile navigation

// website scrollReveal effect
