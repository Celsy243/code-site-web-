<?php require_once("../resources/config.php");?>
<?php require_once(TEMPLATE_FRONT.DS."header.php");?>

<?php
process_transaction();
?>
<div class="container">
<h1 class="text-center">THANK YOU</h1>
</div>
<?php require_once(TEMPLATE_FRONT.DS."footer.php");?>