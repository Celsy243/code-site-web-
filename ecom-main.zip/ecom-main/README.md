# ecom
Un site ecommerce basique avec intégration paypal
Un projet ecommerce avec php 7 pour s'exercer.
Chaque partie ect morcelée de sorte à être compréhensible par n'importe quel débutant.
https://youtu.be/d3iW7XwmYLk
